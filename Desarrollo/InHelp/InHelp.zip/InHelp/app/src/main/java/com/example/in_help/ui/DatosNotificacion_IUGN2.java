package com.example.in_help.ui;

public class DatosNotificacion_IUGN2 {
}
