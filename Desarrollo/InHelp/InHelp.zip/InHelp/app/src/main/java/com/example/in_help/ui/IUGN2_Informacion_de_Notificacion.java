package com.example.in_help.ui;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.in_help.R;

public class IUGN2_Informacion_de_Notificacion extends AppCompatActivity {
    TextView placas,tipoevento,fechanotif,ubica;
    ImageButton detalle;
    ImageView coche;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setupActionBar();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iugn2__informacion_de__notificacion);

        final Datos_IUGN1 objeto = (Datos_IUGN1) getIntent().getExtras().getSerializable("DatosIUGN1");

        coche = (ImageView) findViewById(R.id.IUGN2imageView);

        placas = (TextView) findViewById(R.id.IUGN2textView0);
        tipoevento = (TextView) findViewById(R.id.IUGN2textView);
        fechanotif = (TextView) findViewById(R.id.IUGN2textView3);
        ubica = (TextView) findViewById(R.id.IUGN2textView4);

        detalle = (ImageButton) findViewById(R.id.IUGN2imageButton);



        coche.setImageResource(objeto.getImagen1());
        placas.setText(objeto.getPlacas());

        if(objeto.getImagen1() == R.mipmap.vehiculoa){
            tipoevento.setText("Medio");
        }else if(objeto.getImagen1() == R.mipmap.vehiculor){
            tipoevento.setText("Fuerte");
        }else if(objeto.getImagen1() == R.mipmap.vehiculov){
            tipoevento.setText("Moderado");
        }

        fechanotif.setText(objeto.getFh_notificacion());

    }

    private void setupActionBar(){
        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null)
        {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setTitle("");
        }
    }
}
