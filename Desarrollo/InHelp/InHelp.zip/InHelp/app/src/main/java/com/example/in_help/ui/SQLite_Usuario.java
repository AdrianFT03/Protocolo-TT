package com.example.in_help.ui;

public class SQLite_Usuario {
    
    private Integer id_usuario;
    private Integer id_persona;

    public Integer getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(Integer id_usuario) {
        this.id_usuario = id_usuario;
    }

    public Integer getId_persona() {
        return id_persona;
    }

    public void setId_persona(Integer id_persona) {
        this.id_persona = id_persona;
    }

    public SQLite_Usuario(Integer id_usuario, Integer id_persona) {
        this.id_usuario = id_usuario;
        this.id_persona = id_persona;
    }
}
