package com.example.in_help.ui;

public class LoginRequest {
    public String getTx_password() {
        return tx_password;
    }

    public void setTx_password(String tx_password) {
        this.tx_password = tx_password;
    }

    public String tx_password;
}
