package com.example.in_help.ui;

public class UpdateIdSexo {

    public UpdateIdSexo(Integer id_sexo) {
        this.id_sexo = id_sexo;
    }

    @Override
    public String toString() {
        return "UpdateIdSexo{" +
                "id_sexo=" + id_sexo +
                '}';
    }

    Integer id_sexo;
}
