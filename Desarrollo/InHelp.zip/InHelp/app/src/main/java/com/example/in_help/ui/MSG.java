package com.example.in_help.ui;

import java.util.ArrayList;

public class MSG {
    public MSG(String mensaje) {
        this.mensaje = mensaje;

    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }


    String mensaje;


}







