package com.example.in_help.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.in_help.R;

public class Informacion_General_Notificacion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacion__general__notificacion);
    }
}
